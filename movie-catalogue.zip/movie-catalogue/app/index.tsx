import MoviesScreen from './movies';

export default MoviesScreen;